# APIForge X — Source

See the parent package `Documentation/` for installation, theming, RTL, and adding pages.

```bash
npm install
npm run dev
npm run build
```
