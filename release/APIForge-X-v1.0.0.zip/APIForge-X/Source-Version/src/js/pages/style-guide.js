// =============================================================
// APIForge X — Style Guide page script
// =============================================================

import { boot } from '../main.js';
import { renderLogs } from '../components/table.js';
import { afxToast } from '../components/toast.js';
import { t as tr, onLocaleChange } from '../core/i18n.js';
import logs from '../data/mock-logs.json';

boot();

// Hero table: render 8 of 50 mock requests.
renderLogs(document.querySelector('#logs-demo'), logs, { limit: 8 });

// Toast demo.
document.querySelector('#sg-toast')?.addEventListener('click', () => {
  afxToast({
    message: tr('ui.apiKeyRevoked'),
    type: 'success',
    action: { label: tr('ui.undo'), onClick: () => console.log('undo revoke') },
  });
});

onLocaleChange(() => renderLogs(document.querySelector('#logs-demo'), logs, { limit: 8 }));
