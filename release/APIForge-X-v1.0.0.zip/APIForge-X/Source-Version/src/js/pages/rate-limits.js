// =============================================================
// APIForge X — Rate limits
// Current-limit cards (per minute / per day / monthly), a 14-day
// usage chart with the daily limit, a monthly remaining doughnut,
// and the per-API rules table with warning states. Data-driven.
// =============================================================

import { chartDate, escapeHtml, formatNumber, compactNumber, number } from '../utils/format.js';
import { localizedFixture } from '../data/localized.js';
import { boot } from '../main.js';
import { t as tr, onLocaleChange } from '../core/i18n.js';
import { makeChart, axis, tooltips, initCharts } from '../components/charts.js';
import { createIcons, icons } from '../components/icons.js';
import rateLimitsFa from '../data/mock-rate-limits.json';
import rateLimitsEn from '../data/mock-rate-limits.en.json';

const rateLimits = localizedFixture(rateLimitsFa, rateLimitsEn);

boot();
initCharts();

const { current, history, rules } = rateLimits;

function pct(used, limit) {
  return Math.min(100, (used / limit) * 100);
}
function barClass(p) {
  if (p >= 95) return 'progress-bar--danger';
  if (p >= 80) return 'progress-bar--warning';
  return '';
}

// --- Warning banner ----------------------------------------------------------
function renderBanner() {
  const banner = document.getElementById('rl-banner');
  const breached = rules.filter((r) => r.status === 'breached');
  const near = Object.entries(current).filter(([, v]) => pct(v.used, v.limit) >= 80);
  if (!breached.length && !near.length) {
    banner.innerHTML = '';
    return;
  }
  const hasBreach = breached.length > 0;
  const names = breached.map((r) => r.name).join(', ');
  banner.innerHTML = `
    <div class="alert ${hasBreach ? 'alert-danger' : 'alert-warning'}" role="alert">
      <span class="alert-icon"><i data-lucide="${hasBreach ? 'alert-circle' : 'alert-triangle'}"></i></span>
      <div class="alert-content">
        <div class="fw-medium">${hasBreach ? tr('ratelimits.breached', { names: escapeHtml(names) }) : tr('ratelimits.approaching')}</div>
        <div class="mt-1">${hasBreach ? tr('ratelimits.breachedBody') : tr('ratelimits.approachingBody')}</div>
      </div>
    </div>`;
  createIcons({ icons });
}

// --- Current-limit cards ------------------------------------------------------
function card(label, v, icon) {
  const p = pct(v.used, v.limit);
  return `
    <div class="card limit-card">
      <div class="limit-card__head">
        <span class="limit-card__label">${label}</span>
        <i data-lucide="${icon}"></i>
      </div>
      <div class="limit-card__value">${formatNumber(v.used)} <span class="limit-card__limit">/ ${formatNumber(v.limit)}</span></div>
      <div class="progress" role="img" aria-label="${tr('usage.pctUsed', { pct: number(Math.round(p)) })}">
        <div class="progress-bar ${barClass(p)}" style="width:${p.toFixed(1)}%"></div>
      </div>
      <span class="limit-card__reset"><i data-lucide="clock"></i> ${tr('ui.resetsIn', { time: escapeHtml(v.resetIn) })}</span>
    </div>`;
}

function renderCards() {
  document.getElementById('rl-cards').innerHTML =
    card(tr('ui.requestsMinute'), current.perMinute, 'clock') +
    card(tr('ui.requestsDay'), current.perDay, 'calendar') +
    card(tr('ratelimits.monthlyQuota'), current.monthly, 'pie-chart');
  createIcons({ icons });
}

// --- Charts --------------------------------------------------------------------
function renderHistoryChart() {
  makeChart(document.getElementById('rl-history-chart'), (t) => ({
    type: 'bar',
    data: {
      labels: history.map((d) => chartDate(d.date)),
      datasets: [
        {
          type: 'bar',
          label: tr('table.requests'),
          data: history.map((d) => d.used),
          backgroundColor: t.accent,
          hoverBackgroundColor: t.accent,
          borderRadius: 4,
          borderSkipped: false,
          maxBarThickness: 22,
        },
        {
          type: 'line',
          label: tr('ratelimits.dailyLimit'),
          data: history.map((d) => d.limit),
          borderColor: t.error,
          borderDash: [6, 4],
          borderWidth: 1.5,
          pointRadius: 0,
          pointHitRadius: 8,
          fill: false,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: { x: axis(t), y: axis(t) },
      ...tooltips(t, {
        callbacks: { label: (c) => `${c.dataset.label}: ${compactNumber(c.parsed.y)}` },
      }),
    },
  }));
}

function renderQuotaChart() {
  makeChart(document.getElementById('rl-quota-chart'), (t) => {
    const { used, limit } = current.monthly;
    return {
      type: 'doughnut',
      data: {
        labels: [tr('ui.used'), tr('ui.remaining')],
        datasets: [
          {
            data: [used, Math.max(0, limit - used)],
            backgroundColor: [t.accent, t.surface2],
            borderColor: t.surface2,
            borderWidth: 2,
            hoverOffset: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        ...tooltips(t, {
          callbacks: { label: (c) => `${c.label}: ${tr('ui.requestsValue', { value: formatNumber(c.parsed) })}` },
        }),
      },
    };
  });
}

// --- Rules table ------------------------------------------------------------------
const RULE_STATUS = {
  ok: { label: 'ui.ok', cls: 'badge-status--success' },
  warning: { label: 'ui.warning', cls: 'badge-status--warning' },
  breached: { label: 'ui.breached', cls: 'badge-status--error' },
};

function renderRules() {
  const tbody = document.getElementById('rl-rules');
  tbody.innerHTML = rules
    .map((r) => {
      const s = RULE_STATUS[r.status] || RULE_STATUS.ok;
      const p = pct(r.current, r.limit);
      return `
      <tr>
        <td>
          <div class="fw-medium text-body">${escapeHtml(r.api)}</div>
          <div class="text-tertiary caption ltr-isolate">${escapeHtml(r.name)}</div>
        </td>
        <td><code class="ltr-isolate mono-sm text-body">${tr('ui.requestsValue', { value: number(r.limit) })}</code></td>
        <td><span class="badge badge-neutral">${escapeHtml(r.window)}</span></td>
        <td>
          <div class="rule-usage">
            <div class="progress" role="img" aria-label="${tr('usage.pctUsed', { pct: number(Math.round(p)) })}">
              <div class="progress-bar ${barClass(p)}" style="width:${p.toFixed(1)}%"></div>
            </div>
            <span class="rule-usage__value">${r.current} / ${r.limit}</span>
          </div>
        </td>
        <td><span class="badge badge-status ${s.cls}"><span class="dot"></span>${tr(s.label)}</span></td>
      </tr>`;
    })
    .join('');
  document.getElementById('rl-count').textContent = tr('ui.rulesCount', { count: number(rules.length) });
  createIcons({ icons });
}

// --- Wire --------------------------------------------------------------------
renderBanner();
renderCards();
renderHistoryChart();
renderQuotaChart();
renderRules();

function render() {
  renderBanner();
  renderCards();
  renderHistoryChart();
  renderQuotaChart();
  renderRules();
}

// Re-render when the locale flips.
onLocaleChange(render);
