// =============================================================
// APIForge X — Application entry
// Imports styles (SCSS, fonts) and exposes boot(), which wires all
// global behavior. Each page script calls boot() once — module scripts
// are deferred, so the DOM is ready. Bootstrap's data-APIs are bound
// by importing ./core/bootstrap.js (see that file).
// =============================================================

import '../scss/main.scss';

import { initI18n } from './core/i18n.js';
import { initIcons } from './components/icons.js';
import { initAppShell } from './components/app-shell.js';
import { initTheme } from './components/theme.js';
import { initEnvSwitcher } from './components/env-switcher.js';
import { initCommandPalette } from './components/command-palette.js';
import { initCodeBlocks } from './components/code-block.js';
import { initCopy } from './components/copy.js';
import { initToast } from './components/toast.js';
import { initReveal } from './components/reveal.js';
import { initShortcuts } from './components/shortcuts.js';
import { initMotion } from './components/motion.js';
import './core/bootstrap.js';

export function boot() {
  // Localization first — every later component paints into a translated DOM.
  initI18n();
  initAppShell();
  initIcons();
  initTheme();
  initEnvSwitcher();
  initCommandPalette();
  initCodeBlocks();
  initCopy();
  initToast();
  initReveal();
  initShortcuts();
  // Last: every reveal is measured after the DOM is final.
  initMotion();
}
