import{M as b,o as I,t as a,e as d,s as A,r as y,n as E,d as g,a as v,i as m}from"./bootstrap.esm-Cimvo5LB.js";import{l as _}from"./localized-2wpk38wc.js";import{b as R}from"./main-Bejx2lC8.js";import{a as u}from"./toast-BG8r5azu.js";import{e as S,a as $}from"./mock-environments.en-X4eaaquB.js";import{k as O,a as Z}from"./mock-keys.en-DGrhSoUS.js";const w=[{id:"var_wP7j9pRt",environment:"live",name:"DATABASE_URL",value:"postgres://apiforge:8xK2mQp4@db.apiforge.dev:5432/prod",secret:!0,updatedAt:"2026-09-06T04:27:36.525Z",addedBy:"علی رضایی"},{id:"var_6R6yuVWa",environment:"live",name:"REDIS_URL",value:"rediss://default:r7Xp2mK9@redis.apiforge.dev:6379",secret:!0,updatedAt:"2026-08-18T04:27:36.525Z",addedBy:"سیستم"},{id:"var_BvhyiXfx",environment:"live",name:"WEBHOOK_SIGNING_SECRET",value:"whsec_live_8f3k2ma1q7x9B4dL2nP",secret:!0,updatedAt:"2026-07-18T04:27:36.525Z",addedBy:"علی رضایی"},{id:"var_pJPgx0wh",environment:"live",name:"OPENAI_API_KEY",value:"sk-proj-9xK2mQp4r7Xv1L8nB3dF6",secret:!0,updatedAt:"2026-09-03T04:27:36.525Z",addedBy:"سیستم"},{id:"var_brQFTix5",environment:"live",name:"LOG_LEVEL",value:"info",secret:!1,updatedAt:"2026-09-03T04:27:36.525Z",addedBy:"علی رضایی"},{id:"var_6yRWUayU",environment:"live",name:"FEATURE_FLAGS",value:'{"billing_v2":true,"async_email":false}',secret:!1,updatedAt:"2026-09-01T04:27:36.525Z",addedBy:"سیستم"},{id:"var_0goliNuI",environment:"staging",name:"DATABASE_URL",value:"postgres://apiforge:9bQx7Kp2@db.staging.apiforge.dev:5432/staging",secret:!0,updatedAt:"2026-07-19T04:27:36.525Z",addedBy:"سارا احمدی"},{id:"var_rDKQwX37",environment:"staging",name:"REDIS_URL",value:"redis://redis.staging.apiforge.dev:6379",secret:!0,updatedAt:"2026-08-26T04:27:36.525Z",addedBy:"سیستم"},{id:"var_t10VHB7Q",environment:"staging",name:"WEBHOOK_SIGNING_SECRET",value:"whsec_stag_2mQp4r7Xv1L8nB3d",secret:!0,updatedAt:"2026-08-24T04:27:36.525Z",addedBy:"علی رضایی"},{id:"var_nNPvde6P",environment:"staging",name:"LOG_LEVEL",value:"debug",secret:!1,updatedAt:"2026-08-23T04:27:36.525Z",addedBy:"سارا احمدی"},{id:"var_6jVyPHgt",environment:"test",name:"DATABASE_URL",value:"postgres://localhost:5432/apiforge_dev",secret:!0,updatedAt:"2026-08-17T04:27:36.525Z",addedBy:"علی رضایی"},{id:"var_Ov8jQo27",environment:"test",name:"REDIS_URL",value:"redis://localhost:6379",secret:!0,updatedAt:"2026-07-20T04:27:36.525Z",addedBy:"سیستم"},{id:"var_Aa0YpLtt",environment:"test",name:"WEBHOOK_SIGNING_SECRET",value:"whsec_test_7Xv1L8nB3dF6mQp4",secret:!0,updatedAt:"2026-09-05T04:27:36.525Z",addedBy:"سیستم"},{id:"var_OAVR1hY2",environment:"test",name:"OPENAI_API_KEY",value:"sk-proj-4r7Xv1L8nB3dF6mQp",secret:!0,updatedAt:"2026-08-06T04:27:36.525Z",addedBy:"سیستم"},{id:"var_vcneOmhx",environment:"test",name:"LOG_LEVEL",value:"debug",secret:!1,updatedAt:"2026-08-05T04:27:36.525Z",addedBy:"سیستم"},{id:"var_7lF7RmCl",environment:"test",name:"PORT",value:"4000",secret:!1,updatedAt:"2026-08-25T04:27:36.525Z",addedBy:"علی رضایی"}],D=[{id:"var_wP7j9pRt",environment:"live",name:"DATABASE_URL",value:"postgres://apiforge:8xK2mQp4@db.apiforge.dev:5432/prod",secret:!0,updatedAt:"2026-09-06T04:27:36.525Z",addedBy:"Ali Rezaei"},{id:"var_6R6yuVWa",environment:"live",name:"REDIS_URL",value:"rediss://default:r7Xp2mK9@redis.apiforge.dev:6379",secret:!0,updatedAt:"2026-08-18T04:27:36.525Z",addedBy:"System"},{id:"var_BvhyiXfx",environment:"live",name:"WEBHOOK_SIGNING_SECRET",value:"whsec_live_8f3k2ma1q7x9B4dL2nP",secret:!0,updatedAt:"2026-07-18T04:27:36.525Z",addedBy:"Ali Rezaei"},{id:"var_pJPgx0wh",environment:"live",name:"OPENAI_API_KEY",value:"sk-proj-9xK2mQp4r7Xv1L8nB3dF6",secret:!0,updatedAt:"2026-09-03T04:27:36.525Z",addedBy:"System"},{id:"var_brQFTix5",environment:"live",name:"LOG_LEVEL",value:"info",secret:!1,updatedAt:"2026-09-03T04:27:36.525Z",addedBy:"Ali Rezaei"},{id:"var_6yRWUayU",environment:"live",name:"FEATURE_FLAGS",value:'{"billing_v2":true,"async_email":false}',secret:!1,updatedAt:"2026-09-01T04:27:36.525Z",addedBy:"System"},{id:"var_0goliNuI",environment:"staging",name:"DATABASE_URL",value:"postgres://apiforge:9bQx7Kp2@db.staging.apiforge.dev:5432/staging",secret:!0,updatedAt:"2026-07-19T04:27:36.525Z",addedBy:"Sara Ahmadi"},{id:"var_rDKQwX37",environment:"staging",name:"REDIS_URL",value:"redis://redis.staging.apiforge.dev:6379",secret:!0,updatedAt:"2026-08-26T04:27:36.525Z",addedBy:"System"},{id:"var_t10VHB7Q",environment:"staging",name:"WEBHOOK_SIGNING_SECRET",value:"whsec_stag_2mQp4r7Xv1L8nB3d",secret:!0,updatedAt:"2026-08-24T04:27:36.525Z",addedBy:"Ali Rezaei"},{id:"var_nNPvde6P",environment:"staging",name:"LOG_LEVEL",value:"debug",secret:!1,updatedAt:"2026-08-23T04:27:36.525Z",addedBy:"Sara Ahmadi"},{id:"var_6jVyPHgt",environment:"test",name:"DATABASE_URL",value:"postgres://localhost:5432/apiforge_dev",secret:!0,updatedAt:"2026-08-17T04:27:36.525Z",addedBy:"Ali Rezaei"},{id:"var_Ov8jQo27",environment:"test",name:"REDIS_URL",value:"redis://localhost:6379",secret:!0,updatedAt:"2026-07-20T04:27:36.525Z",addedBy:"System"},{id:"var_Aa0YpLtt",environment:"test",name:"WEBHOOK_SIGNING_SECRET",value:"whsec_test_7Xv1L8nB3dF6mQp4",secret:!0,updatedAt:"2026-09-05T04:27:36.525Z",addedBy:"System"},{id:"var_OAVR1hY2",environment:"test",name:"OPENAI_API_KEY",value:"sk-proj-4r7Xv1L8nB3dF6mQp",secret:!0,updatedAt:"2026-08-06T04:27:36.525Z",addedBy:"System"},{id:"var_vcneOmhx",environment:"test",name:"LOG_LEVEL",value:"debug",secret:!1,updatedAt:"2026-08-05T04:27:36.525Z",addedBy:"System"},{id:"var_7lF7RmCl",environment:"test",name:"PORT",value:"4000",secret:!1,updatedAt:"2026-08-25T04:27:36.525Z",addedBy:"Ali Rezaei"}],P=_($,S),V=_(w,D),K=_(Z,O);R();const U=P,l=[...V],N=K;let s="live";const c=new Set,p=Object.fromEntries(U.map(e=>[e.id,e]));function f(e){return p[e]&&p[e].name||e}function F(){return l.filter(e=>e.environment===s)}function B(){return N.filter(e=>e.env===s)}function T(){const e=document.getElementById("env-notice");s==="live"?e.innerHTML=`
      <div class="alert alert-warning" role="alert">
        <span class="alert-icon"><i data-lucide="alert-triangle"></i></span>
        <div class="alert-content">
          <div class="fw-medium">${a("ui.inProduction")}</div>
          <div class="mt-1">${a("ui.productionWarning")}</div>
        </div>
      </div>`:e.innerHTML="",v({icons:m})}function L(){const e=p[s];document.getElementById("env-summary").innerHTML=`
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
      <div>
        <div class="d-flex align-items-center gap-2">
          <span class="badge badge-status ${s==="live"?"badge-status--success":s==="staging"?"badge-status--warning":"badge-status--info"}"><span class="dot"></span>${d(e.name)}</span>
          <span class="fw-medium text-body">${d(e.description)}</span>
        </div>
        <div class="mt-2 d-flex align-items-center gap-3 flex-wrap text-secondary caption">
          <span class="d-inline-flex align-items-center gap-1"><i data-lucide="globe"></i></span>
          <code class="ltr-isolate mono-sm text-body">${d(e.baseUrl)}</code>
          <button type="button" class="btn btn-icon btn-icon--sm" data-copy="${d(e.baseUrl)}" aria-label="${a("ui.copyBaseUrl")}"><i data-lucide="copy"></i></button>
        </div>
      </div>
      <div class="d-flex align-items-center gap-4 text-end">
        <div>
          <div class="text-tertiary caption">${a("env.apiKeysHeading")}</div>
          <div class="fw-medium text-body tabular-nums">${B().length}</div>
        </div>
        <div>
          <div class="text-tertiary caption">${a("keys.created")}</div>
          <div class="fw-medium text-body">${d(y(e.created))}</div>
        </div>
      </div>
    </div>`,document.querySelectorAll("#env-summary [data-copy]").forEach(g),v({icons:m})}function k(e){return"•".repeat(Math.min(16,Math.max(6,e.length)))}function r(){const e=document.getElementById("var-list"),n=F();n.length?e.innerHTML=n.map(t=>{const i=c.has(t.id),o=!t.secret||i?t.value:k(t.value);return`
        <tr data-id="${d(t.id)}">
          <td>
            <code class="ltr-isolate mono-sm text-body">${d(t.name)}</code>
            <div class="text-tertiary caption">${t.secret?a("env.secret"):a("env.plainText")} · ${a("env.addedBy",{name:d(t.addedBy)})}</div>
          </td>
          <td>
            <span class="d-inline-flex align-items-center gap-2">
              <code class="ltr-isolate mono-sm ${t.secret&&!i?"text-secondary":"text-body"}">${d(o)}</code>
              ${t.secret?`<button type="button" class="btn btn-icon btn-icon--sm" data-var-action="reveal" aria-label="${i?a("env.hideValue"):a("env.revealValue")}"><i data-lucide="${i?"eye-off":"eye"}"></i></button>`:""}
              <button type="button" class="btn btn-icon btn-icon--sm" data-var-action="copy" data-copy="${d(t.value)}" aria-label="${a("ui.copyValue")}"><i data-lucide="copy"></i></button>
              <button type="button" class="btn btn-icon btn-icon--sm" data-var-action="delete" aria-label="${a("ui.deleteVariable")}"><i data-lucide="trash-2"></i></button>
            </span>
          </td>
          <td class="text-secondary" title="${d(A(t.updatedAt))}">${y(t.updatedAt)}</td>
        </tr>`}).join(""):e.innerHTML=`<tr><td colspan="3"><div class="empty-state">
      <span class="empty-icon"><i data-lucide="braces"></i></span>
      <h4 class="empty-title">${a("ui.noVariables")}</h4>
      <p class="empty-desc mb-0">${a("ui.addFirstVariable")}</p>
    </div></td></tr>`,document.getElementById("var-count").textContent=a("env.varsCount",{count:E(n.length),env:f(s)}),e.querySelectorAll("[data-copy]").forEach(g),v({icons:m})}function x(){const e=document.getElementById("env-keys"),n=B();n.length?e.innerHTML=n.map(t=>`
        <tr>
          <td>
            <div class="fw-medium text-body">${d(t.name)}</div>
            <div class="text-tertiary caption">${t.permission==="full"?a("keys.permissionFull"):a("keys.permissionRestricted")}</div>
          </td>
          <td>
            <span class="d-inline-flex align-items-center gap-2">
              <code class="ltr-isolate mono-sm text-secondary">${d(t.prefix)}…</code>
              <button type="button" class="btn btn-icon btn-icon--sm" data-copy="${d(t.prefix)}" aria-label="${a("ui.copyPrefix")}"><i data-lucide="copy"></i></button>
            </span>
          </td>
          <td>${t.scopes.map(i=>`<span class="badge badge-accent ltr-isolate">${d(i)}</span>`).join(" ")}</td>
          <td class="text-secondary" title="${d(A(t.lastUsedAt))}">${y(t.lastUsedAt)}</td>
        </tr>`).join(""):e.innerHTML=`<tr><td colspan="4"><div class="empty-state">
      <span class="empty-icon"><i data-lucide="key"></i></span>
      <h4 class="empty-title">${a("ui.noKeys")}</h4>
      <p class="empty-desc mb-0">${a("ui.firstKey")}</p>
    </div></td></tr>`,document.getElementById("key-count").textContent=a("env.keysCount",{count:E(n.length),env:f(s)}),e.querySelectorAll("[data-copy]").forEach(g),v({icons:m})}function G(){const e=document.getElementById("var-name").value.trim().toUpperCase(),n=document.getElementById("var-value").value,t=document.getElementById("var-secret").checked;if(!e||!n){u({message:a("env.nameValueRequired"),type:"error"});return}l.push({id:`var_new_${Date.now().toString(36)}`,name:e,value:n,secret:t,environment:s,updatedAt:new Date().toISOString(),addedBy:"علی رضایی"}),b.getOrCreateInstance(document.getElementById("variable-modal")).hide(),document.getElementById("var-name").value="",document.getElementById("var-value").value="",u({message:a("ui.variableAdded",{name:e,env:f(s)}),type:"success"}),r()}function Q(e){const n=l.findIndex(i=>i.id===e);if(n<0)return;const[t]=l.splice(n,1);u({message:a("ui.variableDeleted",{name:t.name}),type:"info",action:{label:a("ui.undo"),onClick:()=>{l.splice(n,0,t),r()}}}),r()}function h(e){s=e,document.querySelectorAll("#env-switcher .seg__item").forEach(n=>{const t=n.dataset.envPage===e;n.classList.toggle("is-active",t),n.setAttribute("aria-pressed",String(t))}),T(),L(),r(),x()}document.querySelectorAll("#env-switcher .seg__item").forEach(e=>{e.addEventListener("click",()=>h(e.dataset.envPage))});document.getElementById("variable-create").addEventListener("click",()=>{b.getOrCreateInstance(document.getElementById("variable-modal")).show()});document.getElementById("var-save").addEventListener("click",G);document.getElementById("var-list").addEventListener("click",e=>{const n=e.target.closest("[data-var-action]");if(!n)return;const t=n.closest("tr[data-id]"),i=t&&t.dataset.id,o=n.dataset.varAction;o==="reveal"?(c.has(i)?c.delete(i):c.add(i),r()):o==="delete"&&i&&Q(i)});h("live");function H(){T(),L(),r(),x()}I(H);
