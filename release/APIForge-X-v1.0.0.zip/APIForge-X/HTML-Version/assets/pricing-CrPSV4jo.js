import{o as m,t as a,n,a as u,i as p,v as b}from"./bootstrap.esm-Cimvo5LB.js";import{b as h}from"./site-CAKc0yoM.js";import{a as t}from"./localized-2wpk38wc.js";import{e as r,f as c}from"./mock-plans.en-B4o2ZKcd.js";h();const g=[{key:"requests",labelKey:"plans.requests"},{key:"environments",labelKey:"plans.environments"},{key:"members",labelKey:"plans.members"},{key:"webhooks",labelKey:"plans.webhooks"},{key:"retention",labelKey:"plans.retention"},{key:"rateLimit",labelKey:"plans.rateLimit"},{key:"support",labelKey:"plans.support"}];function o(){const i=document.getElementById("pricing-grid"),l=t(c,r);i.innerHTML=l.map(e=>`
      <div class="pricing-card${e.highlight?" is-featured":""}" data-motion>
        <span class="badge ${e.highlight?"badge-accent":"badge-neutral"} pricing-card__tag">${e.highlight?a("sg.mostPopular"):e.name}</span>
        <div class="pricing-card__name">${e.name}</div>
        <div class="pricing-card__price"><span class="amount">${e.priceLabel}</span><span class="period">${e.period}</span></div>
        <p class="pricing-card__blurb">${e.blurb}</p>
        <ul class="pricing-card__features">
          <li><i data-lucide="check"></i> ${a("plans.requestsValue",{value:e.requests})}</li>
          <li><i data-lucide="check"></i> ${a("plans.environmentsValue",{value:n(e.environments)})}</li>
          <li><i data-lucide="check"></i> ${a("plans.membersValue",{value:n(e.members)})}</li>
          <li><i data-lucide="check"></i> ${a("plans.webhooksValue",{value:n(e.webhooks)})}</li>
          <li><i data-lucide="check"></i> ${a("plans.retentionValue",{value:e.retention})}</li>
          <li><i data-lucide="check"></i> ${a("plans.rateLimitValue",{value:e.rateLimit})}</li>
        </ul>
        <a class="btn ${e.highlight?"btn-primary":"btn-ghost"} pricing-card__cta" href="./dashboard.html">${e.highlight?a("pricing.choosePlan",{plan:e.name}):a("pricing.startWithPlan",{plan:e.name})}</a>
      </div>`).join(""),u({icons:p}),b(i)}function d(){const i=document.querySelector("#pricing-compare tbody"),l=t(c,r);i.innerHTML=g.map(e=>`
      <tr>
        <th scope="row">${a(e.labelKey)}</th>
        ${l.map(s=>`<td class="cell-num">${typeof s[e.key]=="number"?n(s[e.key]):s[e.key]??"—"}</td>`).join("")}
      </tr>`).join("")}o();d();m(()=>{o(),d()});
