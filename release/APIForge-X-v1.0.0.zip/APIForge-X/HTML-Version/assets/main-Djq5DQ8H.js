import{o as _,t as e,g as d,p as c,l as o,k,e as n,r as y,a as p,i as m,n as r,v as $}from"./bootstrap.esm-Cimvo5LB.js";import{b as T}from"./site-CAKc0yoM.js";import{i as C,m as I,t as L,a as l}from"./charts-Cyf2xSom.js";import{a as u}from"./localized-2wpk38wc.js";import{o as g}from"./mock-observability-VMwN_Gm8.js";import{e as P,f as q}from"./mock-activity.en-BJif2DKc.js";import{e as A,f as E}from"./mock-plans.en-B4o2ZKcd.js";T();C();const H={key_created:{icon:"key",cls:"is-success"},webhook_failed:{icon:"webhook",cls:"is-error"},endpoint_updated:{icon:"code-2",cls:""},key_revoked:{icon:"ban",cls:"is-error"},rate_limit:{icon:"gauge",cls:"is-pending"},deploy:{icon:"zap",cls:"is-success"}};function h(){const i=g.ranges["24h"],t=document.getElementById("hero-kpis"),a=[{label:e("kpi.requests24h"),value:d(i.requests),foot:e("dashboard.acrossEndpoints")},{label:e("metrics.errorRate"),value:c(i.errorRate),foot:e("kpi.responseSplit")},{label:e("kpi.p95Latency"),value:o(i.p95),foot:`${e("kpi.p99")} ${o(i.p99)}`},{label:e("kpi.availability"),value:c(i.availability,2),foot:e("kpi.rolling24")}];t.innerHTML=a.map(s=>`
      <div class="card card--dense kpi">
        <span class="kpi-label">${s.label}</span>
        <span class="kpi-value">${s.value}</span>
        <span class="stat-foot">${s.foot}</span>
      </div>`).join("")}function v(){const i=document.getElementById("hero-chart"),t=g.series.slice(-14);I(i,a=>({type:"line",data:{labels:t.map(s=>k(s.date)),datasets:[{data:t.map(s=>s.requests),borderColor:a.accent,backgroundColor:a.accentSoft,borderWidth:1.5,pointRadius:0,pointHoverRadius:3,tension:.35,fill:!0}]},options:{responsive:!0,maintainAspectRatio:!1,scales:{x:l(a),y:{...l(a),ticks:{...l(a).ticks,callback:s=>d(s)}}},...L(a)}}))}function b(){const i=document.getElementById("hero-activity"),t=u(q,P);i.innerHTML=`<ol class="timeline">
    ${t.slice(0,4).map(a=>{const s=H[a.type]||{icon:"activity",cls:""};return`
      <li class="timeline__item">
        <span class="timeline__rail"><span class="timeline__node ${s.cls}"><i data-lucide="${s.icon}"></i></span></span>
        <div class="timeline__content">
          <div class="timeline__title">${n(a.title)}</div>
          <div class="timeline__meta">${n(a.detail)} · ${n(y(a.timestamp))}</div>
        </div>
      </li>`}).join("")}
  </ol>`,p({icons:m})}function f(){const i=document.getElementById("pricing-teaser");if(!i)return;const t=u(E,A);i.innerHTML=t.map(a=>`
      <div class="pricing-card${a.highlight?" is-featured":""}" data-motion>
        <span class="badge ${a.highlight?"badge-accent":"badge-neutral"} pricing-card__tag">${a.highlight?e("sg.mostPopular"):a.name}</span>
        <div class="pricing-card__name">${a.name}</div>
        <div class="pricing-card__price"><span class="amount">${a.priceLabel}</span><span class="period">${a.period}</span></div>
        <p class="pricing-card__blurb">${a.blurb}</p>
        <ul class="pricing-card__features">
          <li><i data-lucide="check"></i> ${e("plans.requestsValue",{value:a.requests})}</li>
          <li><i data-lucide="check"></i> ${e("plans.environmentsValue",{value:r(a.environments)})}</li>
          <li><i data-lucide="check"></i> ${e("plans.webhooksValue",{value:r(a.webhooks)})}</li>
        </ul>
        <a class="btn ${a.highlight?"btn-primary":"btn-ghost"} pricing-card__cta" href="./pricing.html">${a.highlight?e("pricing.choosePlan",{plan:a.name}):e("pricing.startWithPlan",{plan:a.name})}</a>
      </div>`).join(""),p({icons:m}),$(i)}h();v();b();f();_(()=>{h(),v(),b(),f()});
