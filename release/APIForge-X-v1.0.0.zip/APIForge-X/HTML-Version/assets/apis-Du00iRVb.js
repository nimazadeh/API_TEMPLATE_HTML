import{c as y,o as I,e as s,t as a,n as B,a as r,i as l,m as E,b as k,d as S,l as _}from"./bootstrap.esm-Cimvo5LB.js";import{l as h}from"./localized-2wpk38wc.js";import{b as T}from"./main-Bejx2lC8.js";import{a as A,b as C}from"./mock-apis.en-Cxq2h1ok.js";import{e as H,a as M}from"./mock-endpoints.en-BcmhtFh5.js";import{e as F,a as P}from"./mock-environments.en-X4eaaquB.js";import"./toast-BG8r5azu.js";const x=h(C,A),u=h(M,H),f=h(P,F);T();const R={api_emails:"folder-open",api_ai:"activity",api_audiences:"users",api_webhooks:"webhook",api_platform:"settings"},q=e=>x.find(t=>t.id===e)?.name,j={stable:"success",beta:"info",deprecated:"warning"},$=e=>(f.find(t=>t.id===e)||f[0]).baseUrl;let p=u[0];function w(){const e=document.getElementById("api-catalog");e.innerHTML=x.map(t=>`
      <div class="col-12 col-md-6 col-xl-4">
        <button type="button" class="card card--interactive api-card text-body w-100 h-100 text-start" data-api="${t.id}">
          <span class="api-card__head">
            <span class="api-card__icon"><i data-lucide="${R[t.id]}"></i></span>
            <span class="api-card__name">${s(t.name)}</span>
            <span class="badge badge-neutral ms-auto">${s(t.version)}</span>
          </span>
          <span class="api-card__desc">${s(t.description)}</span>
          <span class="api-card__meta">
            <span class="badge badge-status badge-status--${j[t.status]}"><span class="dot"></span>${a(`status.${t.status}`)}</span>
            <span class="text-tertiary caption">${a("ui.endpointsCount",{count:B(t.endpointsCount)})}</span>
          </span>
        </button>
      </div>`).join(""),r({icons:l})}function O(e){return e.map(t=>`
      <tr class="is-clickable" tabindex="0" data-endpoint="${t.id}">
        <td><span class="badge badge-method ${E(t.method)}">${t.method}</span></td>
        <td><code class="ltr-isolate mono-sm text-body">${s(t.path)}</code></td>
        <td class="text-secondary">${s(t.summary)}</td>
        <td class="text-secondary">${s(q(t.apiId)||t.group)}</td>
      </tr>`).join("")}function v(e=""){const t=e.trim().toLowerCase(),n=u.filter(i=>!t||i.method.toLowerCase().includes(t)||i.path.toLowerCase().includes(t)||i.summary.toLowerCase().includes(t)||i.group.toLowerCase().includes(t)),o=document.getElementById("endpoint-list");o.innerHTML=n.length?O(n):`<tr><td colspan="4"><div class="empty-state"><span class="empty-icon"><i data-lucide="search"></i></span><h4 class="empty-title">${a("ui.noEndpoints")}</h4><p class="empty-desc mb-0">${a("ui.tryEndpoint")}</p></div></td></tr>`,r({icons:l})}function b(e,t="JSON"){return`
    <div class="code-block code-block--flush" data-code-block>
      <div class="code-block__header">
        <span class="code-block__lang"><i data-lucide="braces"></i> ${t}</span>
        <div class="code-block__actions"><button type="button" class="btn btn-icon btn-icon--sm" data-code-copy aria-label="${a("aria.copyX",{name:s(t)})}"><i data-lucide="copy"></i></button></div>
      </div>
      <pre class="code-block__body" data-code-pane><code>${s(JSON.stringify(e,null,2))}</code></pre>
    </div>`}function U(e){const t=`${$(y())}${e.path}`,n=e.method==="GET"?"":` -d '${JSON.stringify(e.responseExample).slice(0,120)}…'`;return`
    <div class="code-block" data-code-block>
      <div class="code-block__header">
        <div class="code-tabs" role="tablist" aria-label="${a("profile.language")}">
          <button type="button" class="code-tabs__tab is-active" data-tab="curl">cURL</button>
          <button type="button" class="code-tabs__tab" data-tab="node">Node</button>
          <button type="button" class="code-tabs__tab" data-tab="python">Python</button>
        </div>
        <div class="code-block__actions"><button type="button" class="btn btn-icon" data-code-copy aria-label="${a("common.copy-code")}"><i data-lucide="copy"></i></button></div>
      </div>
      <pre class="code-block__body" data-code-pane data-pane="curl">curl -X ${e.method} ${t} \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json"${n}</pre>
      <pre class="code-block__body" data-code-pane data-pane="node" hidden>import { ApiForge } from '@apiforge/sdk';

const client = new ApiForge('YOUR_API_KEY');
await client.request('${e.method}', '${e.path}');</pre>
      <pre class="code-block__body" data-code-pane data-pane="python" hidden>import apiforge

client = apiforge.Client("YOUR_API_KEY")
resp = client.request("${e.method}", "${e.path}")</pre>
    </div>`}function N(e){return e.params.length?`
    <div class="table-card">
      <div class="table-responsive">
        <table class="params-table">
          <thead><tr><th>${a("table.name")}</th><th>${a("ui.type")}</th><th>${a("ui.requiredHeading")}</th><th>${a("table.description")}</th></tr></thead>
          <tbody>${e.params.map(t=>`<tr>
                <td><span class="param-name">${s(t.name)}</span></td>
                <td><code class="ltr-isolate mono-sm text-tertiary">${s(t.type)}</code></td>
                <td>${t.required?`<span class="param-required">${a("ui.required")}</span>`:`<span class="text-tertiary">${a("ui.optional")}</span>`}</td>
                <td class="param-desc">${s(t.description)}</td>
              </tr>`).join("")}</tbody>
        </table>
      </div>
    </div>`:`<p class="text-secondary">${a("ui.noParameters")}</p>`}function Y(e){const t=document.getElementById("api-doc");t.innerHTML=`
    <div class="endpoint-head mb-3">
      <span class="badge badge-method ${E(e.method)}">${e.method}</span>
      <code class="endpoint-path ltr-isolate">${s(e.path)}</code>
      <button type="button" class="btn btn-icon btn-icon--sm" data-copy="${s(e.path)}" aria-label="${a("ui.copyPath")}"><i data-lucide="copy"></i></button>
    </div>
    <p class="text-secondary body-lg mb-4">${s(e.description)}</p>
    <h4 class="h4 mb-2">${a("ui.parameters")}</h4>
    <div class="mb-4">${N(e)}</div>
    <h4 class="h4 mb-2">${a("ui.codeExamples")}</h4>
    <div class="mb-4">${U(e)}</div>
    <h4 class="h4 mb-2">${a("vs.tab3")}</h4>
    <div>${b(e.responseExample,a("ui.response200"))}</div>`,t.querySelectorAll("[data-code-block]").forEach(k),t.querySelectorAll("[data-copy]").forEach(S),r({icons:l})}function D(e){const t=e.location==="body"?K(e):"";return`
    <div class="tester__param">
      <label class="tester__param-label" for="param-${s(e.name)}">
        <code class="ltr-isolate">${s(e.name)}</code>
        <span class="text-tertiary caption">${s(e.type)}${e.required?` · ${a("ui.required")}`:""}</span>
      </label>
      <input class="form-control${e.type!=="string"?" form-control--mono":""}" id="param-${s(e.name)}" type="text" placeholder="${s(e.name)}" value="${s(t)}" />
    </div>`}function K(e){return{model:"forge-1",prompt:"Summarize the release notes.",input:"How do webhooks work?",to:"user@example.com",subject:"Welcome to APIForge",name:"Trial users",url:"https://example.com/hooks",max_tokens:"256",temperature:"0.7",limit:"50",from:"team@yourco.dev"}[e.name]||""}function z(e){const t=document.getElementById("tester"),n=e.params.filter(d=>d.location!=="path");t.innerHTML=`
    <div class="d-flex align-items-center justify-content-between">
      <h4 class="mb-0">${a("ui.requestBuilder")}</h4>
      <span class="badge badge-neutral">${s(q(e.apiId)||e.group)}</span>
    </div>
    <div class="tester__url">
      <span class="tester__method">${e.method}</span>
      <input class="form-control form-control--mono ltr-isolate" dir="ltr" value="${s($(y())+e.path)}" readonly aria-label="${a("ui.requestUrl")}" />
    </div>
    ${n.length?`<div class="d-flex flex-column gap-3">${n.map(D).join("")}</div>`:`<p class="text-tertiary caption mb-0">${a("ui.noParameters")}</p>`}
    <button type="button" class="btn btn-primary w-100" id="tester-send"><i data-lucide="play"></i> ${a("ui.sendRequest")}</button>
    <div class="response-viewer" id="tester-response" aria-live="polite">
      <div class="response-viewer__status text-tertiary caption">${a("ui.sendForResponse")}</div>
    </div>`;const o=t.querySelector("#tester-send"),i=n.filter(d=>d.required);o.addEventListener("click",()=>{const d=i.filter(c=>!t.querySelector(`#param-${c.name}`)?.value.trim());o.disabled=!0,o.innerHTML=`<span class="spinner"></span> ${a("ui.sending")}`;const g=60+Math.floor(Math.random()*320);setTimeout(()=>{o.disabled=!1,o.innerHTML=`<i data-lucide="play"></i> ${a("ui.sendRequest")}`;const c=t.querySelector("#tester-response");d.length?c.innerHTML=`
          <div class="response-viewer__status">
            <span class="badge badge-status badge-status--warning"><span class="dot"></span>400 Bad Request</span>
            <span class="response-viewer__latency">${_(g)}</span>
          </div>
          ${b({error:{code:"invalid_request",message:`Missing required parameter${d.length>1?"s":""}: ${d.map(L=>L.name).join(", ")}.`}},a("ui.response400"))}`:c.innerHTML=`
          <div class="response-viewer__status">
            <span class="badge badge-status badge-status--success"><span class="dot"></span>200 OK</span>
            <span class="response-viewer__latency">${_(g)}</span>
          </div>
          ${b(e.responseExample,a("ui.response200"))}`,c.querySelectorAll("[data-code-block]").forEach(k),r({icons:l})},450)}),r({icons:l})}function m(e,{scroll:t=!1}={}){p=e,document.querySelectorAll("[data-endpoint]").forEach(n=>n.classList.toggle("is-selected",n.dataset.endpoint===e.id)),Y(e),z(e),t&&document.getElementById("api-doc").scrollIntoView({behavior:"smooth",block:"start"})}w();v();m(p);document.getElementById("api-catalog").addEventListener("click",e=>{const t=e.target.closest("[data-api]");if(!t)return;const n=u.find(o=>o.apiId===t.dataset.api);n&&m(n,{scroll:!0})});document.getElementById("endpoint-list").addEventListener("click",e=>{const t=e.target.closest("[data-endpoint]");if(!t)return;const n=u.find(o=>o.id===t.dataset.endpoint);n&&m(n,{scroll:!0})});document.getElementById("endpoint-search").addEventListener("input",e=>v(e.target.value));document.addEventListener("afx:env",()=>{const e=document.querySelector(".tester__url .form-control");e&&p&&(e.value=$(y())+p.path)});I(()=>{const e=[...document.querySelectorAll("#tester input[id]")].map(t=>[t.id,t.value]);w(),v(document.getElementById("endpoint-search").value),m(p),e.forEach(([t,n])=>{const o=document.getElementById(t);o&&(o.value=n)})});
