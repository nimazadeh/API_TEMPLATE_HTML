import{o as O,e as s,t as n,m as $,n as y,a as E,i as I,d as T,O as A,M as B,h as j}from"./bootstrap.esm-Cimvo5LB.js";import{t as M}from"./localized-view-D3AqM2KF.js";import{l as k}from"./localized-2wpk38wc.js";import{b as H}from"./main-Bejx2lC8.js";import{a as m}from"./toast-BG8r5azu.js";import{e as P,a as D}from"./mock-endpoints.en-BcmhtFh5.js";import{a as F,b as N}from"./mock-apis.en-Cxq2h1ok.js";const z=k(D,P),p=k(N,F);H();const r=[...z],l=Object.fromEntries(p.map(e=>[e.id,e])),J={api_emails:"Bearer token",api_ai:"Bearer token",api_audiences:"Bearer token",api_webhooks:"Signing secret",api_platform:"API key"},i={search:"",method:"all",service:"all",status:"all"};let u=null;function x(e){return l[e.apiId]&&l[e.apiId].name||e.apiId}function L(e){return l[e.apiId]&&l[e.apiId].version||"v1"}function h(e){return l[e.apiId]&&l[e.apiId].status||"stable"}function w(e){return e.auth||J[e.apiId]||"API key"}function f(e){return n({"Bearer token":"form.bearerToken","Signing secret":"form.signingSecret","API key":"keys.apiKeyLabel",None:"form.none"}[w(e)]||"keys.apiKeyLabel")}function K(){const e=i.search.trim().toLowerCase();return r.filter(t=>!(e&&!`${t.path} ${t.description} ${t.summary}`.toLowerCase().includes(e)||i.method!=="all"&&t.method!==i.method||i.service!=="all"&&t.apiId!==i.service||i.status!=="all"&&h(t)!==i.status))}function c(){const e=document.getElementById("endpoint-list"),t=K();t.length?e.innerHTML=t.map(a=>{const o=h(a);return`
        <tr class="is-clickable" tabindex="0" data-id="${s(a.id)}">
          <td><span class="badge badge-method ${$(a.method)}">${a.method}</span></td>
          <td><code class="ltr-isolate mono-sm text-body">${s(a.path)}</code></td>
          <td class="text-secondary">${s(x(a))}</td>
          <td><span class="badge badge-neutral ltr-isolate">${s(L(a))}</span></td>
          <td><span class="badge badge-status ${o==="stable"?"badge-status--success":"badge-status--warning"}"><span class="dot"></span>${n(o==="stable"?"status.stable":"status.beta")}</span></td>
        </tr>`}).join(""):e.innerHTML=`<tr><td colspan="5"><div class="empty-state">
      <span class="empty-icon"><i data-lucide="braces"></i></span>
      <h4 class="empty-title">${n("ui.noEndpoints")}</h4>
      <p class="empty-desc mb-0">${n("logs.emptyDesc")}</p>
    </div></td></tr>`,document.getElementById("endpoint-count").textContent=n("ui.endpointCountOf",{shown:y(t.length),total:y(r.length)}),E({icons:I})}function W(e){return!e.params||!e.params.length?`<div class="text-secondary caption">${n("ui.noParams")}</div>`:`
    <table class="params-table">
      <thead><tr><th>${n("table.name")}</th><th>${n("ui.type")}</th><th>${n("ui.location")}</th><th>${n("table.description")}</th></tr></thead>
      <tbody>${e.params.map(t=>`
        <tr>
          <td><span class="param-name ltr-isolate">${s(t.name)}</span>${t.required?' <span class="param-required">*</span>':""}</td>
          <td><code class="ltr-isolate mono-sm text-secondary">${s(t.type)}</code></td>
          <td><code class="ltr-isolate mono-sm text-secondary">${s(t.location)}</code></td>
          <td class="param-desc">${s(t.description)}</td>
        </tr>`).join("")}</tbody>
    </table>`}function v(e,t,a,o){const d=JSON.stringify(o,null,2);return`
    <div class="code-block code-block--flush">
      <div class="code-block__header">
        <span class="code-block__lang"><i data-lucide="${t}"></i> ${s(e)}</span>
        <div class="code-block__actions">
          <button type="button" class="btn btn-icon btn-icon--sm" data-copy data-copy-target="#${a}" aria-label="${n("aria.copyX",{name:s(e)})}"><i data-lucide="copy"></i></button>
        </div>
      </div>
      <pre class="code-block__body" id="${a}"><code>${j(d)}</code></pre>
    </div>`}function G(e){const t={};return(e.params||[]).forEach(a=>{t[a.name]={type:a.type,required:!!a.required,location:a.location}}),{type:"object",properties:t}}function g(e){const t=document.querySelector("#endpoint-drawer"),a=t.querySelector(".inspector-title"),o=t.querySelector(".offcanvas-body");a.textContent=e.path;const d=h(e);o.innerHTML=`
    <div class="inspector-head">
      <div class="d-flex align-items-center gap-2 flex-wrap">
        <span class="badge badge-method ${$(e.method)}">${e.method}</span>
        <code class="ltr-isolate mono-sm text-body">${s(e.path)}</code>
      </div>
      <div class="d-flex align-items-center gap-2 mt-2 flex-wrap">
        <span class="badge badge-neutral">${s(x(e))}</span>
        <span class="badge badge-neutral ltr-isolate">${s(L(e))}</span>
        <span class="badge badge-status ${d==="stable"?"badge-status--success":"badge-status--warning"}"><span class="dot"></span>${n(d==="stable"?"status.stable":"status.beta")}</span>
        <span class="d-inline-flex align-items-center gap-1 text-secondary caption"><i data-lucide="lock"></i> ${s(f(e))}</span>
      </div>
      <div class="mt-3">
        <button type="button" class="btn btn-sm btn-secondary" data-endpoint-edit><i data-lucide="pencil"></i> ${n("common.edit")}</button>
      </div>
    </div>

    <section class="inspector-section">
      <h4 class="inspector-label">${n("table.description")}</h4>
      <p class="text-secondary mb-0">${s(e.description||e.summary||"—")}</p>
    </section>

    <section class="inspector-section">
      <h4 class="inspector-label">${n("form.authentication")}</h4>
      <div class="d-flex align-items-center gap-2">
        <span class="badge badge-accent"><i data-lucide="shield-check"></i> ${s(f(e))}</span>
      </div>
    </section>

    <section class="inspector-section">
      <h4 class="inspector-label">${n("ui.parameters")}</h4>
      ${W(e)}
    </section>

    <section class="inspector-section">
      <h4 class="inspector-label">${n("ui.requestSchema")}</h4>
      ${v("application/json","braces","ep-request-schema",G(e))}
    </section>

    <section class="inspector-section">
      <h4 class="inspector-label">${n("ui.responseSchema")}</h4>
      ${v("application/json","file-json","ep-response-schema",e.responseExample||{})}
    </section>`,E({icons:I}),o.querySelectorAll("[data-copy]").forEach(T),o.querySelector("[data-endpoint-edit]").addEventListener("click",()=>S(e)),M(t,()=>g(e)),A.getOrCreateInstance(t).show()}function _(){const e=p.map(t=>`<option value="${t.id}">${s(t.name)}</option>`).join("");document.getElementById("ep-service").innerHTML=e,document.getElementById("endpoint-service").innerHTML=`<option value="all">${n("endpoints.allServices")}</option>${e}`}function S(e=null){u=e?e.id:null,document.getElementById("endpoint-modal-title").dataset.i18n=e?"ui.editEndpoint":"endpoints.newEndpointTitle",document.getElementById("endpoint-modal-title").textContent=n(e?"ui.editEndpoint":"endpoints.newEndpointTitle"),document.getElementById("ep-method").value=e?e.method:"GET",document.getElementById("ep-path").value=e?e.path:"/v1/",document.getElementById("ep-service").value=e?e.apiId:p[0].id,document.getElementById("ep-auth").value=e?w(e):"Bearer token",document.getElementById("ep-description").value=e&&e.description||"",B.getOrCreateInstance(document.getElementById("endpoint-modal")).show()}function U(){const e=document.getElementById("ep-method").value,t=document.getElementById("ep-path").value.trim(),a=document.getElementById("ep-service").value,o=document.getElementById("ep-auth").value,d=document.getElementById("ep-description").value.trim();if(!t.startsWith("/")){m({message:n("endpoints.pathInvalid"),type:"error"});return}if(u){const b=r.find(C=>C.id===u);b&&Object.assign(b,{method:e,path:t,apiId:a,auth:o,description:d}),m({message:n("endpoints.updated"),type:"success"})}else r.unshift({id:`ep_new_${Date.now().toString(36)}`,method:e,path:t,apiId:a,auth:o,description:d,summary:d,params:[],responseExample:{ok:!0}}),m({message:n("endpoints.created"),type:"success"});B.getOrCreateInstance(document.getElementById("endpoint-modal")).hide(),c()}_();c();const q=document.getElementById("endpoint-list");q.addEventListener("click",e=>{const t=e.target.closest("tr[data-id]");if(t){const a=r.find(o=>o.id===t.dataset.id);a&&g(a)}});q.addEventListener("keydown",e=>{if(e.key!=="Enter"&&e.key!==" ")return;const t=e.target.closest("tr[data-id]");if(t){e.preventDefault();const a=r.find(o=>o.id===t.dataset.id);a&&g(a)}});document.getElementById("endpoint-create").addEventListener("click",()=>S());document.getElementById("ep-save").addEventListener("click",U);document.getElementById("endpoint-search").addEventListener("input",e=>{i.search=e.target.value,c()});document.getElementById("endpoint-service").addEventListener("change",e=>{i.service=e.target.value,c()});document.getElementById("endpoint-status").addEventListener("change",e=>{i.status=e.target.value,c()});document.querySelectorAll(".filter-bar .seg__item[data-method]").forEach(e=>{e.addEventListener("click",()=>{i.method=e.dataset.method,document.querySelectorAll(".filter-bar .seg__item[data-method]").forEach(t=>{t.classList.toggle("is-active",t===e),t.setAttribute("aria-pressed",String(t===e))}),c()})});O(()=>{const e=document.getElementById("ep-service").value;_(),document.getElementById("endpoint-service").value=i.service,document.getElementById("ep-service").value=e,c()});
