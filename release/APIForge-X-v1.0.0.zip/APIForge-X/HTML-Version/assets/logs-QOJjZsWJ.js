import{e as d,l as p,s as K,u as U,t as a,a as k,i as E,w as h,x as y,O as I,o as T,n as f}from"./bootstrap.esm-Cimvo5LB.js";import{b as B}from"./main-Bejx2lC8.js";import{a as R}from"./table-mIX5_OaI.js";import{t as j}from"./localized-view-D3AqM2KF.js";import{l as v}from"./mock-logs-CnvdaJ3V.js";import"./toast-BG8r5azu.js";function A(e){let t=2166136261;for(let s=0;s<e.length;s++)t^=e.charCodeAt(s),t=Math.imul(t,16777619);return t>>>0}function O(e){return function(){e|=0,e=e+1831565813|0;let t=Math.imul(e^e>>>15,1|e);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}const C={200:"OK",201:"Created",400:"Bad Request",401:"Unauthorized",403:"Forbidden",404:"Not Found",429:"Too Many Requests",500:"Internal Server Error",502:"Bad Gateway",503:"Service Unavailable"},b={400:{code:"invalid_request",messageKey:"error.invalidRequestMessage",explanationKey:"error.invalidRequestExplanation",docsUrl:"https://docs.apiforge.dev/errors/invalid_request"},401:{code:"invalid_api_key",messageKey:"error.invalidKeyMessage",explanationKey:"error.invalidKeyExplanation",docsUrl:"https://docs.apiforge.dev/errors/invalid_api_key"},403:{code:"insufficient_scope",messageKey:"error.insufficientScopeMessage",explanationKey:"error.insufficientScopeExplanation",docsUrl:"https://docs.apiforge.dev/errors/insufficient_scope"},404:{code:"not_found",messageKey:"error.notFoundMessage",explanationKey:"error.notFoundExplanation",docsUrl:"https://docs.apiforge.dev/errors/not_found"},429:{code:"rate_limit_exceeded",messageKey:"error.rateLimitMessage",explanationKey:"error.rateLimitExplanation",docsUrl:"https://docs.apiforge.dev/errors/rate_limit_exceeded"},500:{code:"internal_error",messageKey:"error.internalMessage",explanationKey:"error.internalExplanation",docsUrl:"https://docs.apiforge.dev/errors/internal_error"},502:{code:"upstream_unavailable",messageKey:"error.upstreamMessage",explanationKey:"error.upstreamExplanation",docsUrl:"https://docs.apiforge.dev/errors/upstream_unavailable"},503:{code:"service_unavailable",messageKey:"error.unavailableMessage",explanationKey:"error.unavailableExplanation",docsUrl:"https://docs.apiforge.dev/errors/service_unavailable"}};function F(e){const t=b[e]||b[500];return{code:t.code,message:a(t.messageKey),explanation:a(t.explanationKey),docsUrl:t.docsUrl}}const w={"/v1/emails":{to:"user@example.com",subject:"Welcome to APIForge",html:"<p>Thanks for signing up.</p>",from:"team@yourco.dev"},"/v1/completions":{model:"forge-1",prompt:"Summarize the release notes.",max_tokens:256,temperature:.7},"/v1/embeddings":{model:"embed-1",input:"How do webhooks work?"},"/v1/audiences":{name:"Trial users",filters:[{field:"plan",op:"eq",value:"trial"}]},"/v1/webhooks":{url:"https://example.com/hooks",events:["email.sent","email.bounced"],secret:"whsec_••••"}},D={"/v1/emails":{id:"eml_8Fk2mQx1Zw",status:"queued",to:"user@example.com"},"/v1/completions":{id:"cmpl_9xK2mQ",model:"forge-1",choices:[{text:"Release notes summary…"}]},"/v1/embeddings":{object:"list",data:[{index:0,embedding:[.014,-.021,.038]}]},"/v1/models":{data:[{id:"forge-1",object:"model"},{id:"embed-1",object:"model"}]},"/v1/audiences":{id:"aud_9xK2mQ",name:"Trial users",size:12840},"/v1/webhooks":{id:"wh_8f3k2ma1",url:"https://example.com/hooks",enabled:!0},"/v1/api-keys":{id:"key_DElNoSR8",revoked:!0},"/v1/usage":{requests:5382400,period:{start:"2026-09-01",end:"2026-09-30"}}};function N(e){return Object.keys(w).find(t=>e.startsWith(t))||"/v1/emails"}function z(e){const t=O(A(e.id)),s=N(e.path),r=e.method==="GET",c=C[e.status]||"Unknown",o=e.status>=400?F(e.status):null,i=Math.round(e.latencyMs*(.08+t()*.1)),l=Math.round(e.latencyMs*(.55+t()*.15)),m=e.latencyMs-i-l;return{id:e.id,method:e.method,path:e.path,status:e.status,statusText:c,latencyMs:e.latencyMs,env:e.env,key:e.keyPrefix,timestamp:e.timestamp,userAgent:e.userAgent,ip:`${Math.floor(20+t()*200)}.${Math.floor(t()*255)}.${Math.floor(t()*255)}.${Math.floor(1+t()*254)}`,region:["fra1","iad1","sin1","syd1"][Math.floor(t()*4)],request:{headers:[["Authorization",`Bearer ${e.keyPrefix}…`],["Content-Type","application/json"],["User-Agent",e.userAgent],["Idempotency-Key",e.id],["X-APIForge-Env",e.env]],query:r?{limit:50,before:"req_"+Math.floor(t()*9e9)}:null,body:r?null:w[s]},response:{headers:[["Content-Type","application/json"],["Request-Id",e.id],...e.status===429?[["Retry-After","2"]]:[]],body:o?{error:{code:o.code,message:o.message,docs:o.docsUrl}}:D[s]},timing:{queue:i,processing:l,response:m},error:o}}function _(e){const t=[`curl ${e.method==="GET"?"":"-X "+e.method} https://api${e.env==="test"?".test":""}.apiforge.dev${e.path}`];return e.request.headers.forEach(([s,r])=>t.push(`  -H "${s}: ${r}"`)),e.request.body&&t.push(`  -d '${JSON.stringify(e.request.body)}'`),t.join(` \\
`)}function g(e){return`<table class="kv"><tbody>${e.map(([t,s])=>`<tr><th scope="row"><code class="ltr-isolate">${d(t)}</code></th><td><code class="ltr-isolate">${d(s)}</code></td></tr>`).join("")}</tbody></table>`}function x(e){const t=JSON.stringify(e,null,2);return`
    <div class="code-block code-block--flush">
      <div class="code-block__header">
        <span class="code-block__lang"><i data-lucide="braces"></i> JSON</span>
        <div class="code-block__actions">
          <button type="button" class="btn btn-icon btn-icon--sm" data-copy-json aria-label="${a("aria.copyJson")}"><i data-lucide="copy"></i></button>
        </div>
      </div>
      <pre class="code-block__body"><code>${d(t)}</code></pre>
    </div>`}function q(e,t=document.querySelector("#log-drawer")){if(!t)return;const s=z(e),r=t.querySelector(".inspector-title"),c=t.querySelector(".offcanvas-body");r&&(r.textContent=s.id);const o=`badge-method--${s.method}`,i=s.status>=500?"badge-status--error":s.status===429?"badge-status--429":s.status>=400?"badge-status--warning":"badge-status--success";c.innerHTML=`
    <div class="inspector-head">
      <div class="d-flex align-items-center gap-2 flex-wrap">
        <span class="badge badge-method ${o}">${s.method}</span>
        <code class="ltr-isolate mono-sm text-body">${d(s.path)}</code>
        <span class="badge badge-status ${i}"><span class="dot"></span>${s.status} ${s.statusText}</span>
      </div>
      <div class="d-flex align-items-center gap-3 mt-2 text-secondary caption">
        <span class="d-inline-flex align-items-center gap-1"><i data-lucide="timer"></i> ${p(s.latencyMs)}</span>
        <span class="d-inline-flex align-items-center gap-1"><i data-lucide="calendar"></i> ${d(K(s.timestamp))}</span>
        <span class="d-inline-flex align-items-center gap-1"><i data-lucide="globe"></i> ${d(U(s.env))}</span>
      </div>
    </div>

    <section class="inspector-section">
      <h4 class="inspector-label">${a("inspector.timing")}</h4>
      <div class="timing-bars">
        <div class="timing-row">
          <span class="timing-row__name">${a("inspector.queue")}</span>
          <div class="timing-row__track"><div class="timing-row__fill" style="width:${Math.max(4,s.timing.queue/s.latencyMs*100)}%"></div></div>
          <span class="timing-row__value">${p(s.timing.queue)}</span>
        </div>
        <div class="timing-row">
          <span class="timing-row__name">${a("inspector.processing")}</span>
          <div class="timing-row__track"><div class="timing-row__fill is-accent" style="width:${Math.max(4,s.timing.processing/s.latencyMs*100)}%"></div></div>
          <span class="timing-row__value">${p(s.timing.processing)}</span>
        </div>
        <div class="timing-row">
          <span class="timing-row__name">${a("inspector.response")}</span>
          <div class="timing-row__track"><div class="timing-row__fill is-muted" style="width:${Math.max(4,s.timing.response/s.latencyMs*100)}%"></div></div>
          <span class="timing-row__value">${p(s.timing.response)}</span>
        </div>
      </div>
    </section>

    <section class="inspector-section">
      <div class="d-flex align-items-center justify-content-between mb-2">
        <h4 class="inspector-label mb-0">${a("inspector.request")}</h4>
        <button type="button" class="btn btn-sm btn-ghost" data-copy-curl aria-label="${a("inspector.copyAsCurl")}"><i data-lucide="copy"></i> ${a("inspector.copyAsCurl")}</button>
      </div>
      <div class="code-block code-block--flush mb-2">
        <div class="code-block__header"><span class="code-block__lang"><i data-lucide="terminal"></i> cURL</span></div>
        <pre class="code-block__body"><code>${d(_(s))}</code></pre>
      </div>
      ${s.request.query?g(Object.entries(s.request.query)):""}
      ${s.request.body?x(s.request.body):""}
      <div class="inspector-sub mt-2">${a("inspector.headers")}</div>
      ${g(s.request.headers)}
    </section>

    <section class="inspector-section">
      <h4 class="inspector-label">${a("inspector.response")}</h4>
      ${s.error?`
        <div class="alert alert-danger mb-2" role="alert">
          <span class="alert-icon"><i data-lucide="alert-circle"></i></span>
          <div class="alert-content">
            <div class="fw-medium">${d(s.error.message)}</div>
            <div class="mt-1">${d(s.error.explanation)}</div>
            <a class="d-inline-flex align-items-center gap-1 mt-1" href="${s.error.docsUrl}" target="_blank" rel="noopener">${a("inspector.readDocs")} <i data-lucide="external-link"></i></a>
          </div>
        </div>`:""}
      ${x(s.response.body)}
      <div class="inspector-sub mt-2">${a("inspector.headers")}</div>
      ${g(s.response.headers)}
    </section>

    <section class="inspector-section">
      <h4 class="inspector-label">${a("inspector.context")}</h4>
      ${g([[a("inspector.environment"),s.env],[a("inspector.apiKey"),s.key+"…"],[a("inspector.ip"),s.ip],[a("inspector.region"),s.region]])}
    </section>`,k({icons:E}),c.querySelectorAll("[data-copy-curl]").forEach(l=>{l.addEventListener("click",async()=>h(l,await y(_(s))))}),c.querySelectorAll("[data-copy-json]").forEach(l=>{l.addEventListener("click",async()=>{const m=l.closest(".code-block")?.querySelector(".code-block__body");h(l,await y(m?m.textContent.trim():""))})}),j(t,()=>q(e,t)),I.getOrCreateInstance(t).show()}B();const n={search:"",method:"all",status:"all",env:"all",range:"all"},$={"1h":36e5,"24h":864e5,"7d":6048e5};function M(){const e=n.search.trim().toLowerCase(),t=$[n.range]?Date.now()-$[n.range]:0;return v.filter(s=>{if(e&&!s.path.toLowerCase().includes(e)||n.method!=="all"&&s.method!==n.method)return!1;if(n.status!=="all"){const r=Math.floor(s.status/100),c=n.status==="2xx"?2:n.status==="4xx"?4:n.status==="5xx"?5:0;if(r!==c)return!1}return!(n.env!=="all"&&s.env!==n.env||t&&new Date(s.timestamp).getTime()<t)})}function u(){const e=M(),t=document.getElementById("logs-list");e.length?R(t,e):t.innerHTML=`
      <tr><td colspan="7">
        <div class="empty-state">
          <span class="empty-icon"><i data-lucide="search"></i></span>
          <h4 class="empty-title">${a("logs.emptyTitle")}</h4>
          <p class="empty-desc mb-0">${a("logs.emptyDesc")}</p>
        </div>
      </td></tr>`,document.getElementById("logs-count").textContent=a("logs.countOf",{shown:f(e.length),total:f(v.length)}),k({icons:E})}function L(e){const t=v.find(s=>s.id===e.dataset.id);t&&q(t)}function G(){const e=M(),t=["id","method","path","status","latency_ms","environment","timestamp"],s=e.map(i=>[i.id,i.method,i.path,i.status,i.latencyMs,i.env,i.timestamp].join(",")),r=new Blob([[t.join(","),...s].join(`
`)],{type:"text/csv"}),c=URL.createObjectURL(r),o=document.createElement("a");o.href=c,o.download="apiforge-logs.csv",document.body.appendChild(o),o.click(),o.remove(),URL.revokeObjectURL(c)}u();const S=document.getElementById("logs-list");S.addEventListener("click",e=>{const t=e.target.closest("tr[data-id]");t&&L(t)});S.addEventListener("keydown",e=>{if(e.key!=="Enter"&&e.key!==" ")return;const t=e.target.closest("tr[data-id]");t&&(e.preventDefault(),L(t))});document.getElementById("logs-search").addEventListener("input",e=>{n.search=e.target.value,u()});document.querySelectorAll(".filter-bar .seg__item[data-method]").forEach(e=>{e.addEventListener("click",()=>{n.method=e.dataset.method,document.querySelectorAll(".filter-bar .seg__item[data-method]").forEach(t=>{t.classList.toggle("is-active",t===e),t.setAttribute("aria-pressed",String(t===e))}),u()})});document.getElementById("logs-status").addEventListener("change",e=>{n.status=e.target.value,u()});document.getElementById("logs-env").addEventListener("change",e=>{n.env=e.target.value,u()});document.getElementById("logs-range").addEventListener("change",e=>{n.range=e.target.value,u()});document.getElementById("logs-clear").addEventListener("click",()=>{Object.assign(n,{search:"",method:"all",status:"all",env:"all",range:"all"}),document.getElementById("logs-search").value="",document.getElementById("logs-status").value="all",document.getElementById("logs-env").value="all",document.getElementById("logs-range").value="all",document.querySelectorAll(".filter-bar .seg__item[data-method]").forEach(e=>{e.classList.toggle("is-active",e.dataset.method==="all"),e.setAttribute("aria-pressed",String(e.dataset.method==="all"))}),u()});document.getElementById("logs-refresh").addEventListener("click",u);document.getElementById("logs-export").addEventListener("click",G);T(u);
