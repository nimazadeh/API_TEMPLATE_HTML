import{o as l,t as i,b as p,w as d,x as g,a as m,i as u,e as a,f}from"./bootstrap.esm-Cimvo5LB.js";import{l as y}from"./localized-2wpk38wc.js";import{b}from"./main-Bejx2lC8.js";import"./toast-BG8r5azu.js";const h=[{id:"js",name:"JavaScript",lang:"JS",accent:"js",package:"@apiforge/sdk",version:"1.7.2",install:"npm install @apiforge/sdk",registry:"npm",updated:"2026-09-05T04:27:36.526Z",features:["تایپ‌های TypeScript","پشتیبانی از جریان","تلاش مجدد و یکتایی","ابزار بررسی امضای وب‌هوک"],docsUrl:"./docs.html"},{id:"node",name:"Node.js",lang:"Node",accent:"node",package:"apiforge",version:"2.1.0",install:"npm install apiforge",registry:"npm",updated:"2026-08-30T04:27:36.526Z",features:["بدون وابستگی","پشتیبانی از جریان","تلاش مجدد و یکتایی","سازگار با ESM و CJS"],docsUrl:"./docs.html"},{id:"python",name:"Python",lang:"Py",accent:"py",package:"apiforge",version:"1.4.1",install:"pip install apiforge",registry:"PyPI",updated:"2026-08-25T04:27:36.526Z",features:["کلاینت همزمان و ناهمزمان","پاسخ‌های تایپ‌شده","تلاش مجدد و یکتایی","فیکسچرهای pytest"],docsUrl:"./docs.html"},{id:"php",name:"PHP",lang:"PHP",accent:"php",package:"apiforge/apiforge-php",version:"0.9.3",install:"composer require apiforge/apiforge-php",registry:"Packagist",updated:"2026-08-17T04:27:36.526Z",features:["سازگار با PSR-18","انتقال بر پایهٔ Guzzle","ابزار بررسی امضای وب‌هوک"],docsUrl:"./docs.html"},{id:"go",name:"Go",lang:"Go",accent:"go",package:"github.com/apiforge/apiforge-go",version:"1.2.4",install:"go get github.com/apiforge/apiforge-go",registry:"Go modules",updated:"2026-08-28T04:27:36.526Z",features:["آگاه از context","بدون تخصیص حافظه در مسیر پرمصرف","تلاش مجدد و یکتایی"],docsUrl:"./docs.html"},{id:"ruby",name:"Ruby",lang:"Rb",accent:"rb",package:"apiforge",version:"0.8.0",install:"gem install apiforge",registry:"RubyGems",updated:"2026-08-09T04:27:36.526Z",features:["یکپارچه با ActiveSupport","تلاش مجدد و یکتایی","ابزار بررسی امضای وب‌هوک"],docsUrl:"./docs.html"}],v=[{id:"js",name:"JavaScript",lang:"JS",accent:"js",package:"@apiforge/sdk",version:"1.7.2",install:"npm install @apiforge/sdk",registry:"npm",updated:"2026-09-05T04:27:36.526Z",features:["TypeScript types","Streaming support","Retries and idempotency","Webhook signature verification"],docsUrl:"./docs.html"},{id:"node",name:"Node.js",lang:"Node",accent:"node",package:"apiforge",version:"2.1.0",install:"npm install apiforge",registry:"npm",updated:"2026-08-30T04:27:36.526Z",features:["Zero dependencies","Streaming support","Retries and idempotency","ESM and CJS compatible"],docsUrl:"./docs.html"},{id:"python",name:"Python",lang:"Py",accent:"py",package:"apiforge",version:"1.4.1",install:"pip install apiforge",registry:"PyPI",updated:"2026-08-25T04:27:36.526Z",features:["Sync and async clients","Typed responses","Retries and idempotency","pytest fixtures"],docsUrl:"./docs.html"},{id:"php",name:"PHP",lang:"PHP",accent:"php",package:"apiforge/apiforge-php",version:"0.9.3",install:"composer require apiforge/apiforge-php",registry:"Packagist",updated:"2026-08-17T04:27:36.526Z",features:["PSR-18 compatible","Guzzle transport","Webhook signature verification"],docsUrl:"./docs.html"},{id:"go",name:"Go",lang:"Go",accent:"go",package:"github.com/apiforge/apiforge-go",version:"1.2.4",install:"go get github.com/apiforge/apiforge-go",registry:"Go modules",updated:"2026-08-28T04:27:36.526Z",features:["Context-aware","Zero allocations on hot paths","Retries and idempotency"],docsUrl:"./docs.html"},{id:"ruby",name:"Ruby",lang:"Rb",accent:"rb",package:"apiforge",version:"0.8.0",install:"gem install apiforge",registry:"RubyGems",updated:"2026-08-09T04:27:36.526Z",features:["ActiveSupport integration","Retries and idempotency","Webhook signature verification"],docsUrl:"./docs.html"}],k=y(h,v);b();const x={js:`import { ApiForge } from '@apiforge/sdk';

const api = new ApiForge('YOUR_API_KEY');
const email = await api.emails.send({ to: 'user@example.com', subject: 'Welcome' });`,node:`import { ApiForge } from 'apiforge';

const api = new ApiForge('YOUR_API_KEY');
await api.request('GET', '/v1/models');`,python:`import apiforge

client = apiforge.Client("YOUR_API_KEY")
resp = client.emails.send(to="user@example.com", subject="Welcome")
print(resp.id)`,php:`use ApiForge\\Client;

$client = new Client('YOUR_API_KEY');
$email = $client->emails->send(['to' => 'user@example.com', 'subject' => 'Welcome']);`,go:`package main

import "github.com/apiforge/apiforge-go"

func main() {
    c := apiforge.New("YOUR_API_KEY")
    _ = c.Emails.Send(apiforge.Email{To: "user@example.com"})
}`,ruby:`require "apiforge"

client = ApiForge::Client.new("YOUR_API_KEY")
email = client.emails.send(to: "user@example.com", subject: "Welcome")`};function P(e){return`
    <article class="card sdk-card d-flex flex-column" data-sdk="${e.id}">
      <div class="d-flex align-items-center gap-3 mb-3">
        <span class="sdk-mark sdk-mark--${e.accent}">${a(e.lang)}</span>
        <div class="min-w-0">
          <h4 class="mb-0">${a(e.name)}</h4>
          <div class="caption text-tertiary ltr-isolate">${a(e.package)} · v${a(e.version)}</div>
        </div>
      </div>
      <p class="text-secondary mb-3">${a(e.registry)} · ${i("ui.updatedAt",{date:f(e.updated)})}</p>
      <div class="install-row d-flex align-items-center gap-2 mb-3">
        <code class="ltr-isolate mono-sm text-body text-truncate flex-grow-1">${a(e.install)}</code>
        <button type="button" class="btn btn-icon btn-icon--sm" data-copy="${a(e.install)}" aria-label="${i("ui.copyInstall")}"><i data-lucide="copy"></i></button>
      </div>
      <ul class="list-unstyled d-flex flex-column gap-1 mb-4">
        ${e.features.map(o=>`<li class="caption text-secondary d-flex align-items-center gap-2"><i data-lucide="check" class="text-accent" style="width:13px;height:13px"></i> ${a(o)}</li>`).join("")}
      </ul>
      <div class="mt-auto">
        <div class="code-block code-block--flush mb-3" data-code-block>
          <div class="code-block__header">
            <span class="code-block__lang"><i data-lucide="terminal"></i> ${i("ui.quickStart")}</span>
            <div class="code-block__actions"><button type="button" class="btn btn-icon btn-icon--sm" data-code-copy aria-label="${i("ui.copyExample")}"><i data-lucide="copy"></i></button></div>
          </div>
          <pre class="code-block__body" data-code-pane><code>${a(x[e.id]||"")}</code></pre>
        </div>
        <a class="btn btn-ghost btn-sm w-100" href="${e.docsUrl}">${i("site.documentation")} <i data-lucide="arrow-up-right"></i></a>
      </div>
    </article>`}function c(e=""){const o=e.trim().toLowerCase(),n=k.filter(t=>!o||[t.name,t.package,t.lang,t.registry].some(r=>r.toLowerCase().includes(o))),s=document.getElementById("sdk-grid");s.innerHTML=n.length?n.map(P).join(""):`<div class="col-12"><div class="empty-state"><span class="empty-icon"><i data-lucide="package"></i></span><h4 class="empty-title">${i("ui.noSdks")}</h4><p class="empty-desc mb-0">${i("ui.trySdk")}</p></div></div>`,s.querySelectorAll("[data-code-block]").forEach(p),s.querySelectorAll("[data-copy]").forEach(t=>{t.addEventListener("click",async()=>d(t,await g(t.dataset.copy||"")))}),m({icons:u})}c();document.getElementById("sdk-search").addEventListener("input",e=>c(e.target.value));l(()=>c(document.getElementById("sdk-search").value));
