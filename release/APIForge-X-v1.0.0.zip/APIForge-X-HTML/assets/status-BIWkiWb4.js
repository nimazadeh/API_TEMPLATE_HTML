import{o as u,t as s,n as r,a as m,i as l,f as p}from"./bootstrap.esm-BcAGarmG.js";import{b as y}from"./site-CvEGbUxm.js";y();const K=[{nameKey:"status.componentGateway",descKey:"status.componentGatewayDesc"},{nameKey:"status.componentLogs",descKey:"status.componentLogsDesc"},{nameKey:"status.componentWebhooks",descKey:"status.componentWebhooksDesc"},{nameKey:"status.componentDashboard",descKey:"status.componentDashboardDesc"},{nameKey:"status.componentBilling",descKey:"status.componentBillingDesc"},{nameKey:"status.componentStatus",descKey:"status.componentStatusDesc"}],f=[{date:"2026-09-02",titleKey:"status.incident1Title",descKey:"status.incident1Desc",statusKey:"status.resolved"},{date:"2026-08-19",titleKey:"status.incident2Title",descKey:"status.incident2Desc",statusKey:"status.resolved"}];function g(e){let t=e>>>0;return()=>(t=t*1664525+1013904223>>>0,t/4294967295)}function v(){const e=document.getElementById("uptime-bars"),t=g(20260908),a=[];for(let n=0;n<90;n++){const o=t(),c=n===27||n===63,d=c?62+Math.round(o*8):92+Math.round(o*8);a.push(`<span class="uptime-bar${c?" is-degraded":""}" style="height:${d}%" title="${s("ui.day",{count:r(90-n)})}"></span>`)}e.innerHTML=a.join("")}function h(){const e=document.getElementById("components-list");e.innerHTML=K.map(t=>`
      <div class="status-components__row">
        <div>
          <div class="fw-medium">${s(t.nameKey)}</div>
          <div class="caption text-tertiary">${s(t.descKey)}</div>
        </div>
        <span class="badge badge-status--success"><i data-lucide="check"></i> ${s("status.operational")}</span>
      </div>`).join(""),m({icons:l})}function b(){const e=document.getElementById("incidents-list");e.innerHTML=f.map(t=>`
      <div class="incidents__item">
        <span class="incidents__date ltr-isolate">${p(t.date)}</span>
        <div>
          <div class="incidents__title">${s(t.titleKey)}</div>
          <div class="incidents__desc">${s(t.descKey)}</div>
          <span class="badge badge-neutral mt-2">${s(t.statusKey)}</span>
        </div>
      </div>`).join("")}function i(){v(),h(),b()}i();u(i);
