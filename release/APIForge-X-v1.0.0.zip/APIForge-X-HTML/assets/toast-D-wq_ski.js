import{e as n,t as b,a as v,i as f,N as h}from"./bootstrap.esm-BcAGarmG.js";const i={success:"circle-check",error:"alert-circle",warning:"alert-triangle",info:"info"},r={error:!0,warning:!0};function l(){let e=document.querySelector(".toast-stack");return e||(e=document.createElement("div"),e.className="toast-stack",document.body.appendChild(e)),e}function k({title:e="",message:d="",type:c="success",action:a=null,delay:u=4e3}={}){const s=i[c]?c:"info",m=l(),t=document.createElement("div");t.className="toast",t.dataset.type=s,t.setAttribute("role",r[s]?"alert":"status"),t.setAttribute("aria-live",r[s]?"assertive":"polite"),t.setAttribute("aria-atomic","true");const p=e?`<span class="toast__title">${n(e)}</span>`:"",_=a?`<button type="button" class="toast__action">${n(a.label)}</button>`:"";t.innerHTML=`
    <span class="toast__icon" aria-hidden="true"><i data-lucide="${i[s]}"></i></span>
    <div class="toast__content">
      ${p}
      <span class="toast__message">${n(d)}</span>
      ${_}
    </div>
    <button type="button" class="toast__close" aria-label="${n(b("aria.close"))}">
      <i data-lucide="x"></i>
    </button>`,m.appendChild(t),v({icons:f});const o=h.getOrCreateInstance(t,{delay:u,autohide:!a});return t.querySelector(".toast__action")?.addEventListener("click",()=>{a.onClick?.(),o.hide()}),t.querySelector(".toast__close")?.addEventListener("click",()=>o.hide()),t.addEventListener("hidden.bs.toast",()=>t.remove()),o.show(),t}function $(){l()}window.afxToast=k;export{k as a,$ as i};
