import{d as n,a as o,i,t as s,e as a,f as $,s as c,r as l,B as r,m as p,C as b,l as u}from"./bootstrap.esm-BcAGarmG.js";function y(t){return`
    <tr class="is-clickable" tabindex="0" data-id="${a(t.id)}">
      <td class="text-tertiary" title="${a(c(t.timestamp))}">
        <span class="tabular-nums">${a(l(t.timestamp))}</span>
      </td>
      <td><span class="badge badge-method ${p(t.method)}">${a(t.method)}</span></td>
      <td><code class="ltr-isolate mono-sm text-body">${a(t.path)}</code></td>
      <td><span class="badge badge-status ${r(t.status)}"><span class="dot"></span>${t.status}</span></td>
      <td class="cell-num"><span class="latency ${b(t.latencyMs)}">${u(t.latencyMs)}</span></td>
      <td>
        <span class="d-inline-flex align-items-center gap-1">
          <code class="ltr-isolate mono-sm text-secondary">${a(t.id)}</code>
          <button type="button" class="btn btn-icon btn-icon--sm" data-copy="${a(t.id)}" aria-label="${s("aria.copyRequestId")}" data-bs-toggle="tooltip" data-bs-title="${s("aria.copyId")}">
            <i data-lucide="copy"></i>
          </button>
        </span>
      </td>
      <td><code class="ltr-isolate mono-sm text-tertiary">${a(t.keyPrefix)}</code></td>
    </tr>`}function x(t){return`
    <tr class="is-clickable" tabindex="0" data-id="${a(t.id)}" data-env="${a(t.env)}" data-method="${a(t.method)}" data-status="${t.status}">
      <td><span class="badge badge-status ${r(t.status)}"><span class="dot"></span>${t.status}</span></td>
      <td><span class="badge badge-method ${p(t.method)}">${a(t.method)}</span></td>
      <td><code class="ltr-isolate mono-sm text-body">${a(t.path)}</code></td>
      <td class="cell-num"><span class="latency ${b(t.latencyMs)}">${u(t.latencyMs)}</span></td>
      <td class="text-secondary tabular-nums" title="${a(c(t.timestamp))}">${a(l(t.timestamp))}</td>
      <td>
        <span class="d-inline-flex align-items-center gap-1">
          <code class="ltr-isolate mono-sm text-secondary">${a(t.id)}</code>
          <button type="button" class="btn btn-icon btn-icon--sm" data-copy="${a(t.id)}" aria-label="${s("common.copy-request-id")}" data-bs-toggle="tooltip" data-bs-title="${s("common.copy-id")}">
            <i data-lucide="copy"></i>
          </button>
        </span>
      </td>
      <td><code class="ltr-isolate mono-sm text-tertiary">${a(t.keyPrefix)}</code></td>
    </tr>`}function v(t){const e=t.status==="revoked",d=t.permission==="full"?s("keys.permissionFull"):s("keys.permissionRestricted");return`
    <tr class="is-clickable" tabindex="0" data-id="${a(t.id)}">
      <td>
        <div class="fw-medium text-body">${a(t.name)}</div>
        <div class="text-tertiary caption">${s("keys.created")} ${a($(t.createdAt))}</div>
      </td>
      <td>
        <span class="d-inline-flex align-items-center gap-1">
          <code class="ltr-isolate mono-sm text-secondary">${a(t.prefix)}…</code>
          <button type="button" class="btn btn-icon btn-icon--sm" data-copy="${a(t.prefix)}" aria-label="${s("aria.copyKey")}" data-bs-toggle="tooltip" data-bs-title="${s("aria.copyKey")}">
            <i data-lucide="copy"></i>
          </button>
        </span>
      </td>
      <td>
        <span class="badge ${e?"badge-neutral":"badge-accent"}">${d}</span>
      </td>
      <td>
        <span class="badge ${t.env==="live"?"badge-status--success":"badge-status--info"}"><span class="dot"></span>${t.env==="live"?s("env.liveOption"):s("env.testOption")}</span>
      </td>
      <td class="text-secondary tabular-nums" title="${a(c(t.lastUsedAt))}">${a(l(t.lastUsedAt))}</td>
      <td class="text-tertiary">
        <span class="d-inline-flex align-items-center gap-2">
          <span class="badge badge-status ${e?"badge-status--error":"badge-status--success"}"><span class="dot"></span>${e?s("status.revoked"):s("status.activePlain")}</span>
          <span class="row-actions dropdown" data-dropdown>
            <button type="button" class="btn btn-icon btn-icon--sm" data-bs-toggle="dropdown" aria-label="${s("aria.actionsFor",{name:a(t.name)})}" aria-expanded="false">
              <i data-lucide="more-horizontal"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-end">
              <button type="button" class="dropdown-item" data-key-action="reveal"><i data-lucide="eye"></i> ${s("action.reveal")}</button>
              <button type="button" class="dropdown-item" data-key-action="rotate"${e?" disabled":""}><i data-lucide="rotate-ccw"></i> ${s("action.rotate")}</button>
              <hr class="dropdown-divider" />
              <button type="button" class="dropdown-item is-danger" data-key-action="revoke"${e?" disabled":""}><i data-lucide="ban"></i> ${s("action.revoke")}</button>
            </div>
          </span>
        </span>
      </td>
    </tr>`}function h(t,e,{limit:d}={}){const m=(d?e.slice(0,d):e).map(y).join("");t.innerHTML=m,t.querySelectorAll("[data-copy]").forEach(n),o({icons:i})}function w(t,e){t.innerHTML=e.map(x).join(""),t.querySelectorAll("[data-copy]").forEach(n),o({icons:i})}function g(t,e){t.innerHTML=e.map(v).join(""),t.querySelectorAll("[data-copy]").forEach(n),o({icons:i})}export{w as a,h as b,g as r};
