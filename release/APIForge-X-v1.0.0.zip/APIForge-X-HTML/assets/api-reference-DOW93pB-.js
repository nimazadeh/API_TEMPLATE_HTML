import{o as $,t as a,e as o,m as u,b as g,d as _,a as k,i as E,O as I,h as m}from"./bootstrap.esm-BcAGarmG.js";import{l as h}from"./localized-DOgIWQCH.js";import{b as B}from"./main-BBj0WUUP.js";import{a as x,b as q}from"./mock-apis.en-Cxq2h1ok.js";import{e as K,a as A}from"./mock-endpoints.en-BcmhtFh5.js";import"./toast-D-wq_ski.js";const y=h(q,x),d=h(A,K);B();const S={api_emails:"form.bearerToken",api_ai:"form.bearerToken",api_audiences:"form.bearerToken",api_webhooks:"form.signingSecret",api_platform:"keys.apiKeyLabel"},b={400:{code:"invalid_request",messageKey:"error.invalidRequestMessage"},401:{code:"invalid_api_key",messageKey:"error.invalidKeyMessage"},403:{code:"insufficient_scope",messageKey:"error.insufficientScopeMessage"},404:{code:"not_found",messageKey:"error.notFoundMessage"},429:{code:"rate_limit_exceeded",messageKey:"error.rateLimitMessage"},500:{code:"internal_error",messageKey:"error.internalMessage"}},n={service:"all",endpoint:d[0].id};function v(){return n.service==="all"?d:d.filter(e=>e.apiId===n.service)}function f(){const e=[`<option value="all">${a("endpoints.allServices")}</option>`,...y.map(t=>`<option value="${t.id}">${o(t.name)}</option>`)].join("");document.getElementById("ref-service").innerHTML=e}function p(){const t=y.map(l=>{const i=v().filter(c=>c.apiId===l.id);return i.length?`
      <div class="docs-nav__group">
        <div class="docs-nav__label">${o(l.name)}</div>
        ${i.map(c=>`<a class="docs-nav__item ref-nav__item ${n.endpoint===c.id?"is-active":""}" href="#${c.id}" data-ep="${c.id}">
              <span class="badge badge-method ${u(c.method)}">${c.method}</span>
              <code class="ltr-isolate mono-sm text-secondary text-truncate">${o(c.path.replace("/v1/",""))}</code>
            </a>`).join("")}
      </div>`:""}).join("");document.getElementById("ref-nav").innerHTML=t;const s=document.getElementById("ref-nav-mobile");s&&(s.innerHTML=t)}function L(e){return e.params.length?`
    <div class="table-card">
      <div class="table-responsive">
        <table class="table params-table">
          <thead><tr><th scope="col">${a("table.name")}</th><th scope="col">${a("ui.type")}</th><th scope="col">${a("ui.location")}</th><th scope="col">${a("ui.requiredHeading")}</th><th scope="col">${a("table.description")}</th></tr></thead>
          <tbody>${e.params.map(t=>`<tr>
                <td><code class="ltr-isolate mono-sm text-body">${o(t.name)}</code></td>
                <td><code class="ltr-isolate mono-sm text-tertiary">${o(t.type)}</code></td>
                <td><code class="ltr-isolate mono-sm text-tertiary">${o(t.location)}</code></td>
                <td>${t.required?`<span class="badge badge-accent">${a("ui.required")}</span>`:`<span class="text-tertiary">${a("ui.optional")}</span>`}</td>
                <td class="param-desc">${o(t.description)}</td>
              </tr>`).join("")}</tbody>
        </table>
      </div>
    </div>`:`<p class="text-secondary mb-0">${a("ui.noParameters")}</p>`}function T(e){const t={};(e.params||[]).forEach(i=>{i.location==="body"&&(t[i.name]={type:i.type,required:!!i.required})});const l=JSON.stringify({type:"object",properties:t},null,2);return`
    <div class="code-block code-block--flush">
      <div class="code-block__header">
        <span class="code-block__lang"><i data-lucide="braces"></i> ${a("ui.requestBodySchema")}</span>
        <div class="code-block__actions"><button type="button" class="btn btn-icon btn-icon--sm" data-copy-target="#ref-request-schema" aria-label="${a("ui.copySchema")}"><i data-lucide="copy"></i></button></div>
      </div>
      <pre class="code-block__body" id="ref-request-schema"><code>${m(l)}</code></pre>
    </div>`}function H(e){const t=JSON.stringify(e.responseExample,null,2);return`
    <div class="code-block code-block--flush">
      <div class="code-block__header">
        <span class="code-block__lang"><i data-lucide="file-json"></i> ${a("ui.response200")}</span>
        <div class="code-block__actions"><button type="button" class="btn btn-icon btn-icon--sm" data-copy-target="#ref-response" aria-label="${a("ui.copyResponse")}"><i data-lucide="copy"></i></button></div>
      </div>
      <pre class="code-block__body" id="ref-response"><code>${m(t)}</code></pre>
    </div>`}function O(e){const t=`https://api.apiforge.dev${e.path}`;return`
    <div class="code-block" data-code-block>
      <div class="code-block__header">
        <div class="code-tabs" role="tablist" aria-label="${a("profile.language")}">
          <button type="button" class="code-tabs__tab is-active" data-tab="curl">cURL</button>
          <button type="button" class="code-tabs__tab" data-tab="node">Node</button>
          <button type="button" class="code-tabs__tab" data-tab="python">Python</button>
          <button type="button" class="code-tabs__tab" data-tab="php">PHP</button>
        </div>
        <div class="code-block__actions"><button type="button" class="btn btn-icon btn-icon--sm" data-code-copy aria-label="${a("common.copy-code")}"><i data-lucide="copy"></i></button></div>
      </div>
      <pre class="code-block__body" data-code-pane data-pane="curl"><code>${o(`curl ${e.method==="GET"?"":`-X ${e.method} `}${t} \\
  -H "Authorization: Bearer YOUR_API_KEY"`)}</code></pre>
      <pre class="code-block__body" data-code-pane data-pane="node" hidden><code>${o(`import { ApiForge } from '@apiforge/sdk';

const client = new ApiForge('YOUR_API_KEY');
await client.request('${e.method}', '${e.path}');`)}</code></pre>
      <pre class="code-block__body" data-code-pane data-pane="python" hidden><code>${o(`import apiforge

client = apiforge.Client("YOUR_API_KEY")
resp = client.request("${e.method}", "${e.path}")`)}</code></pre>
      <pre class="code-block__body" data-code-pane data-pane="php" hidden><code>${o(`use ApiForge\\Client;

$client = new Client('YOUR_API_KEY');
$response = $client->request('${e.method}', '${e.path}');`)}</code></pre>
    </div>`}function r(){const e=d.find(s=>s.id===n.endpoint)||d[0],t=a(S[e.apiId]||"keys.apiKeyLabel");document.getElementById("ref-crumb").textContent=e.path,document.getElementById("ref-doc").innerHTML=`
    <div class="endpoint-head mb-3">
      <span class="badge badge-method ${u(e.method)}">${e.method}</span>
      <code class="endpoint-path ltr-isolate">${o(e.path)}</code>
      <button type="button" class="btn btn-icon btn-icon--sm" data-copy="${o(e.path)}" aria-label="${a("ui.copyPath")}"><i data-lucide="copy"></i></button>
    </div>
    <p class="text-secondary body-lg mb-4">${o(e.description)}</p>

    <section class="inspector-section">
      <h4 class="inspector-label">${a("form.authentication")}</h4>
      <div class="d-flex align-items-center gap-2">
        <span class="badge badge-accent"><i data-lucide="shield-check"></i> ${o(t)}</span>
        <span class="text-tertiary caption">${a("ui.includeHeader")} <code class="ltr-isolate">Authorization</code> ${a("ui.headerEveryRequest")}</span>
      </div>
    </section>

    <section class="inspector-section">
      <h4 class="inspector-label">${a("ui.parameters")}</h4>
      ${L(e)}
    </section>

    ${e.params.some(s=>s.location==="body")?`<section class="inspector-section"><h4 class="inspector-label">${a("ui.requestBody")}</h4>${T(e)}</section>`:""}

    <section class="inspector-section">
      <h4 class="inspector-label">${a("vs.tab3")}</h4>
      ${H(e)}
    </section>

    <section class="inspector-section">
      <h4 class="inspector-label">${a("table.errors")}</h4>
      <div class="table-card">
        <div class="table-responsive">
          <table class="table">
            <thead><tr><th scope="col">${a("table.status")}</th><th scope="col">${a("ui.code")}</th><th scope="col">${a("table.description")}</th></tr></thead>
            <tbody>${[400,401,403,404,429].map(s=>`<tr>
                  <td><span class="badge badge-status ${s===429?"badge-status--429":"badge-status--warning"}">${s}</span></td>
                  <td><code class="ltr-isolate mono-sm text-body">${b[s].code}</code></td>
                  <td class="text-secondary">${o(a(b[s].messageKey))}</td>
                </tr>`).join("")}</tbody>
          </table>
        </div>
      </div>
    </section>

    <section class="inspector-section">
      <h4 class="inspector-label">${a("ui.codeSamples")}</h4>
      ${O(e)}
    </section>`,document.querySelectorAll("#ref-doc [data-code-block]").forEach(g),document.querySelectorAll("#ref-doc [data-copy]").forEach(_),k({icons:E})}function R(e){n.endpoint=e,p(),r(),window.scrollTo({top:0});const t=document.getElementById("ref-nav-offcanvas");t&&I.getOrCreateInstance(t).hide()}f();p();r();document.getElementById("ref-service").addEventListener("change",e=>{n.service=e.target.value;const t=v()[0];t&&(n.endpoint=t.id),p(),r()});[document.getElementById("ref-nav"),document.getElementById("ref-nav-mobile")].forEach(e=>{e&&e.addEventListener("click",t=>{const s=t.target.closest("[data-ep]");s&&(t.preventDefault(),R(s.dataset.ep))})});document.getElementById("ref-version").addEventListener("change",()=>{r()});$(()=>{f(),document.getElementById("ref-service").value=n.service,p(),r()});
