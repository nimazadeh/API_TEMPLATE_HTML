# APIForge X — Preview package (v1.0.0)

This folder is the **instant, standalone preview** of APIForge X.

## How to open it

1. Unzip the package (if you are reading this inside an archive).
2. Double-click `index.html`.

That is all — no npm, no Node.js, no web server, no internet connection
needed. Every one of the **31 pages** opens directly from the
file system (`file://`), fonts and assets are included locally, and the
Persian RTL layout, themes (dark / light / system) and all animations work
as designed.

## Pages

- `404.html`
- `api-keys.html`
- `api-reference.html`
- `apis.html`
- `billing.html`
- `changelog.html`
- `dashboard.html`
- `docs.html`
- `endpoints.html`
- `environments.html`
- `errors.html`
- `forgot-password.html`
- `index.html`
- `invite.html`
- `login.html`
- `logs.html`
- `metrics.html`
- `notifications.html`
- `pricing.html`
- `profile.html`
- `rate-limits.html`
- `rtl-persian-test.html`
- `rtl.html`
- `sdk.html`
- `settings.html`
- `status.html`
- `style-guide.html`
- `team.html`
- `usage.html`
- `visual-showcase.html`
- `webhooks.html`

## Notes

- All assets live under `assets/`: `css/main.css` (one stylesheet for all
  pages), `js/*.js` (one classic script per page) and `fonts/`
  (self-hosted woff2/woff). Relative paths only.
- For customization, use the **APIForge-X-Developer** package (Vite source)
  that ships with this release.
- `LICENSE.txt` applies.
